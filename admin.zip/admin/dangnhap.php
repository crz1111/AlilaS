<link rel="stylesheet" href="style.css">
<div class="row mb">
                <div class="boxtitle">Dang nhap Admin</div>
                <div class="boxcontent formtaikhoan">
                    <form action="index.php?act=dangnhap" method="post">
                        <div class="row mb10">
                            User<br>
                        <input type="text" name="user">
                        </div>
                        <div class="row mb10">
                            Password<br>
                        <input type="password" name="pass"><br>
                        </div>
                        <div class="row mb10">
                            <input type="checkbox" name="" id="">Remember me ?<br>
                        </div>
                        <div class="row mb10">
                            <input type="submit" value="Login" name="dangnhap">
                        </div>
                    </form>
                </div>
            </div>